﻿#include <Windows.h>
#include <iostream>
#include <conio.h>
#include "WinUser.h"
using namespace std;
bool key(int _key = VK_F7, int _key2 = VK_MENU) {
	if (GetAsyncKeyState(_key) == -32767 && GetAsyncKeyState(_key2) == -32767) {
		cout << "\a";
		return true;
	}
	return false;
}int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	bool w1 = true, w2 = false, w3 = false, w4 = false;
	while (true) {
		if (key()) {
			if (w1) {
				SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, (PVOID) L"L:\\Progs C++\\Wallpapers\\кот.bmp", SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
				w1 = false;
				w2 = true;
			}
			else if (w2) {
				SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, (PVOID) L"L:\\Progs C++\\Wallpapers\\кот2.bmp", SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
				w2 = false;
				w3 = true;
			}
			else if (w3) {
				SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, (PVOID) L"L:\\Progs C++\\Wallpapers\\кот3.jpg", SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
				w3 = false;
				w4 = true;
			}
			else if (w4) {
				SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, (PVOID) L"L:\\Progs C++\\Wallpapers\\кот4.jpg", SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
				w4 = false;
				w1 = true;
			}
		} Sleep(100);
	} 
}